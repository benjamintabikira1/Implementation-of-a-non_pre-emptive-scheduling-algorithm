#include <stdio.h>
#include <stdlib.h>

struct Job {
    char name[10];
    float estimated_run_time;
    float waiting_time;
    float priority;
};

void calculate_priority(struct Job jobs[], int n) {
    for (int i = 0; i < n; i++) {
        jobs[i].priority = 1 + (jobs[i].waiting_time / jobs[i].estimated_run_time);
    }
}

void swap(struct Job *a, struct Job *b) {
    struct Job temp = *a;
    *a = *b;
    *b = temp;
}

void sort_by_priority(struct Job jobs[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (jobs[j].priority > jobs[j + 1].priority) {
                swap(&jobs[j], &jobs[j + 1]);
            }
        }
    }
}

int main() {
    int n;
    printf("Enter the number of jobs: ");
    scanf("%d", &n);

    struct Job jobs[n];

    for (int i = 0; i < n; i++) {
        printf("Enter the name of Job %d: ", i + 1);
        scanf("%s", jobs[i].name);
        printf("Enter the estimated run time for Job %d: ", i + 1);
        scanf("%f", &jobs[i].estimated_run_time);
        jobs[i].waiting_time = 0;
        jobs[i].priority = 1;
    }

    int current_time = 0;
    int completed_jobs = 0;

    printf("Gantt Chart: ");
    while (completed_jobs < n) {
        calculate_priority(jobs, n);
        sort_by_priority(jobs, n);

        for (int i = 0; i < n; i++) {
            if (jobs[i].estimated_run_time > 0 && jobs[i].waiting_time <= current_time) {
                printf("%s -> ", jobs[i].name);
                jobs[i].estimated_run_time -= 1;
                current_time++;
                if (jobs[i].estimated_run_time == 0) {
                    completed_jobs++;
                }
            } else {
                jobs[i].waiting_time++;
            }
        }
    }
    printf("\n");

    float total_waiting_time = 0;
    for (int i = 0; i < n; i++) {
        total_waiting_time += jobs[i].waiting_time;
    }

    for (int i = 0; i < n; i++) {
        printf("Waiting time for %s: %.2f\n", jobs[i].name, jobs[i].waiting_time);
    }

    float average_waiting_time = total_waiting_time / n;
    printf("Average Waiting Time: %.2f\n", average_waiting_time);

    return 0;
}